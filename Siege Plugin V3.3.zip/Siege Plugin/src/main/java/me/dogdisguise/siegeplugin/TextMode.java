

package me.dogdisguise.siegeplugin;

import org.bukkit.ChatColor;

//just a few constants for chat color codes
public class TextMode
{
    final static ChatColor Info = ChatColor.AQUA;
    final static ChatColor Instr = ChatColor.YELLOW;
    final static ChatColor Warn = ChatColor.GOLD;
    final static ChatColor Err = ChatColor.RED;
    final static ChatColor Success = ChatColor.GREEN;
}
